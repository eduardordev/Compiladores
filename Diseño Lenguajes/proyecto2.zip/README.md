# Compis

Aqui vamos a rogarle a Dios que nos ayude a crear la base del compilador.
