
#Este código servirá para la implementación del archivo .py que va a usar la implementación de la info del yalex. 

class infoYal:

    def __init__(self, lista_diccionarios, lista_iniciales, lista_finales, archivo, res_list):
        self.lista_diccionarios = lista_diccionarios
        self.lista_iniciales = lista_iniciales
        self.lista_finales = lista_finales
        self.archivo = archivo
        self.res_list = res_list
