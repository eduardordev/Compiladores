# Generated from Compiscript.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,63,478,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,
        2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,33,
        7,33,2,34,7,34,2,35,7,35,2,36,7,36,2,37,7,37,2,38,7,38,2,39,7,39,
        2,40,7,40,2,41,7,41,2,42,7,42,2,43,7,43,2,44,7,44,2,45,7,45,1,0,
        5,0,94,8,0,10,0,12,0,97,9,0,1,0,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
        1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,3,1,119,8,1,1,2,1,2,
        5,2,123,8,2,10,2,12,2,126,9,2,1,2,1,2,1,3,1,3,1,3,3,3,133,8,3,1,
        3,3,3,136,8,3,1,3,1,3,1,4,1,4,1,4,3,4,143,8,4,1,4,1,4,1,4,1,4,1,
        5,1,5,1,5,1,6,1,6,1,6,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,
        7,1,7,3,7,167,8,7,1,8,1,8,1,8,1,9,1,9,1,9,1,9,1,9,1,9,1,10,1,10,
        1,10,1,10,1,10,1,10,1,10,3,10,185,8,10,1,11,1,11,1,11,1,11,1,11,
        1,11,1,12,1,12,1,12,1,12,1,12,1,12,1,12,1,12,1,13,1,13,1,13,1,13,
        1,13,3,13,206,8,13,1,13,3,13,209,8,13,1,13,1,13,3,13,213,8,13,1,
        13,1,13,1,13,1,14,1,14,1,14,1,14,1,14,1,14,1,14,1,14,1,15,1,15,1,
        15,1,16,1,16,1,16,1,17,1,17,3,17,234,8,17,1,17,1,17,1,18,1,18,1,
        18,1,18,1,18,1,18,1,18,1,18,1,19,1,19,1,19,1,19,1,19,1,19,5,19,252,
        8,19,10,19,12,19,255,9,19,1,19,3,19,258,8,19,1,19,1,19,1,20,1,20,
        1,20,1,20,5,20,266,8,20,10,20,12,20,269,9,20,1,21,1,21,1,21,5,21,
        274,8,21,10,21,12,21,277,9,21,1,22,1,22,1,22,1,22,3,22,283,8,22,
        1,22,1,22,1,22,3,22,288,8,22,1,22,1,22,1,23,1,23,1,23,5,23,295,8,
        23,10,23,12,23,298,9,23,1,24,1,24,1,24,3,24,303,8,24,1,25,1,25,1,
        25,1,25,3,25,309,8,25,1,25,1,25,5,25,313,8,25,10,25,12,25,316,9,
        25,1,25,1,25,1,26,1,26,1,26,3,26,323,8,26,1,27,1,27,1,28,1,28,1,
        28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,3,28,338,8,28,1,29,1,
        29,1,29,1,29,1,29,1,29,3,29,346,8,29,1,30,1,30,1,30,5,30,351,8,30,
        10,30,12,30,354,9,30,1,31,1,31,1,31,5,31,359,8,31,10,31,12,31,362,
        9,31,1,32,1,32,1,32,5,32,367,8,32,10,32,12,32,370,9,32,1,33,1,33,
        1,33,5,33,375,8,33,10,33,12,33,378,9,33,1,34,1,34,1,34,5,34,383,
        8,34,10,34,12,34,386,9,34,1,35,1,35,1,35,5,35,391,8,35,10,35,12,
        35,394,9,35,1,36,1,36,1,36,3,36,399,8,36,1,37,1,37,1,37,1,37,1,37,
        1,37,3,37,407,8,37,1,38,1,38,1,38,1,38,1,38,3,38,414,8,38,1,39,1,
        39,5,39,418,8,39,10,39,12,39,421,9,39,1,40,1,40,1,40,1,40,1,40,3,
        40,428,8,40,1,40,1,40,3,40,432,8,40,1,41,1,41,3,41,436,8,41,1,41,
        1,41,1,41,1,41,1,41,1,41,1,41,3,41,445,8,41,1,42,1,42,1,42,5,42,
        450,8,42,10,42,12,42,453,9,42,1,43,1,43,1,43,1,43,5,43,459,8,43,
        10,43,12,43,462,9,43,3,43,464,8,43,1,43,1,43,1,44,1,44,1,44,5,44,
        471,8,44,10,44,12,44,474,9,44,1,45,1,45,1,45,0,0,46,0,2,4,6,8,10,
        12,14,16,18,20,22,24,26,28,30,32,34,36,38,40,42,44,46,48,50,52,54,
        56,58,60,62,64,66,68,70,72,74,76,78,80,82,84,86,88,90,0,7,1,0,3,
        4,1,0,34,35,1,0,36,39,1,0,40,41,1,0,42,44,2,0,41,41,45,45,2,0,53,
        55,60,60,499,0,95,1,0,0,0,2,118,1,0,0,0,4,120,1,0,0,0,6,129,1,0,
        0,0,8,139,1,0,0,0,10,148,1,0,0,0,12,151,1,0,0,0,14,166,1,0,0,0,16,
        168,1,0,0,0,18,171,1,0,0,0,20,177,1,0,0,0,22,186,1,0,0,0,24,192,
        1,0,0,0,26,200,1,0,0,0,28,217,1,0,0,0,30,225,1,0,0,0,32,228,1,0,
        0,0,34,231,1,0,0,0,36,237,1,0,0,0,38,245,1,0,0,0,40,261,1,0,0,0,
        42,270,1,0,0,0,44,278,1,0,0,0,46,291,1,0,0,0,48,299,1,0,0,0,50,304,
        1,0,0,0,52,322,1,0,0,0,54,324,1,0,0,0,56,337,1,0,0,0,58,339,1,0,
        0,0,60,347,1,0,0,0,62,355,1,0,0,0,64,363,1,0,0,0,66,371,1,0,0,0,
        68,379,1,0,0,0,70,387,1,0,0,0,72,398,1,0,0,0,74,406,1,0,0,0,76,413,
        1,0,0,0,78,415,1,0,0,0,80,431,1,0,0,0,82,444,1,0,0,0,84,446,1,0,
        0,0,86,454,1,0,0,0,88,467,1,0,0,0,90,475,1,0,0,0,92,94,3,2,1,0,93,
        92,1,0,0,0,94,97,1,0,0,0,95,93,1,0,0,0,95,96,1,0,0,0,96,98,1,0,0,
        0,97,95,1,0,0,0,98,99,5,0,0,1,99,1,1,0,0,0,100,119,3,6,3,0,101,119,
        3,8,4,0,102,119,3,14,7,0,103,119,3,44,22,0,104,119,3,50,25,0,105,
        119,3,16,8,0,106,119,3,18,9,0,107,119,3,4,2,0,108,119,3,20,10,0,
        109,119,3,22,11,0,110,119,3,24,12,0,111,119,3,26,13,0,112,119,3,
        28,14,0,113,119,3,36,18,0,114,119,3,38,19,0,115,119,3,30,15,0,116,
        119,3,32,16,0,117,119,3,34,17,0,118,100,1,0,0,0,118,101,1,0,0,0,
        118,102,1,0,0,0,118,103,1,0,0,0,118,104,1,0,0,0,118,105,1,0,0,0,
        118,106,1,0,0,0,118,107,1,0,0,0,118,108,1,0,0,0,118,109,1,0,0,0,
        118,110,1,0,0,0,118,111,1,0,0,0,118,112,1,0,0,0,118,113,1,0,0,0,
        118,114,1,0,0,0,118,115,1,0,0,0,118,116,1,0,0,0,118,117,1,0,0,0,
        119,3,1,0,0,0,120,124,5,1,0,0,121,123,3,2,1,0,122,121,1,0,0,0,123,
        126,1,0,0,0,124,122,1,0,0,0,124,125,1,0,0,0,125,127,1,0,0,0,126,
        124,1,0,0,0,127,128,5,2,0,0,128,5,1,0,0,0,129,130,7,0,0,0,130,132,
        5,60,0,0,131,133,3,10,5,0,132,131,1,0,0,0,132,133,1,0,0,0,133,135,
        1,0,0,0,134,136,3,12,6,0,135,134,1,0,0,0,135,136,1,0,0,0,136,137,
        1,0,0,0,137,138,5,5,0,0,138,7,1,0,0,0,139,140,5,6,0,0,140,142,5,
        60,0,0,141,143,3,10,5,0,142,141,1,0,0,0,142,143,1,0,0,0,143,144,
        1,0,0,0,144,145,5,7,0,0,145,146,3,54,27,0,146,147,5,5,0,0,147,9,
        1,0,0,0,148,149,5,8,0,0,149,150,3,88,44,0,150,11,1,0,0,0,151,152,
        5,7,0,0,152,153,3,54,27,0,153,13,1,0,0,0,154,155,5,60,0,0,155,156,
        5,7,0,0,156,157,3,54,27,0,157,158,5,5,0,0,158,167,1,0,0,0,159,160,
        3,54,27,0,160,161,5,9,0,0,161,162,5,60,0,0,162,163,5,7,0,0,163,164,
        3,54,27,0,164,165,5,5,0,0,165,167,1,0,0,0,166,154,1,0,0,0,166,159,
        1,0,0,0,167,15,1,0,0,0,168,169,3,54,27,0,169,170,5,5,0,0,170,17,
        1,0,0,0,171,172,5,10,0,0,172,173,5,11,0,0,173,174,3,54,27,0,174,
        175,5,12,0,0,175,176,5,5,0,0,176,19,1,0,0,0,177,178,5,13,0,0,178,
        179,5,11,0,0,179,180,3,54,27,0,180,181,5,12,0,0,181,184,3,4,2,0,
        182,183,5,14,0,0,183,185,3,4,2,0,184,182,1,0,0,0,184,185,1,0,0,0,
        185,21,1,0,0,0,186,187,5,15,0,0,187,188,5,11,0,0,188,189,3,54,27,
        0,189,190,5,12,0,0,190,191,3,4,2,0,191,23,1,0,0,0,192,193,5,16,0,
        0,193,194,3,4,2,0,194,195,5,15,0,0,195,196,5,11,0,0,196,197,3,54,
        27,0,197,198,5,12,0,0,198,199,5,5,0,0,199,25,1,0,0,0,200,201,5,17,
        0,0,201,205,5,11,0,0,202,206,3,6,3,0,203,206,3,14,7,0,204,206,5,
        5,0,0,205,202,1,0,0,0,205,203,1,0,0,0,205,204,1,0,0,0,206,208,1,
        0,0,0,207,209,3,54,27,0,208,207,1,0,0,0,208,209,1,0,0,0,209,210,
        1,0,0,0,210,212,5,5,0,0,211,213,3,54,27,0,212,211,1,0,0,0,212,213,
        1,0,0,0,213,214,1,0,0,0,214,215,5,12,0,0,215,216,3,4,2,0,216,27,
        1,0,0,0,217,218,5,18,0,0,218,219,5,11,0,0,219,220,5,60,0,0,220,221,
        5,19,0,0,221,222,3,54,27,0,222,223,5,12,0,0,223,224,3,4,2,0,224,
        29,1,0,0,0,225,226,5,20,0,0,226,227,5,5,0,0,227,31,1,0,0,0,228,229,
        5,21,0,0,229,230,5,5,0,0,230,33,1,0,0,0,231,233,5,22,0,0,232,234,
        3,54,27,0,233,232,1,0,0,0,233,234,1,0,0,0,234,235,1,0,0,0,235,236,
        5,5,0,0,236,35,1,0,0,0,237,238,5,23,0,0,238,239,3,4,2,0,239,240,
        5,24,0,0,240,241,5,11,0,0,241,242,5,60,0,0,242,243,5,12,0,0,243,
        244,3,4,2,0,244,37,1,0,0,0,245,246,5,25,0,0,246,247,5,11,0,0,247,
        248,3,54,27,0,248,249,5,12,0,0,249,253,5,1,0,0,250,252,3,40,20,0,
        251,250,1,0,0,0,252,255,1,0,0,0,253,251,1,0,0,0,253,254,1,0,0,0,
        254,257,1,0,0,0,255,253,1,0,0,0,256,258,3,42,21,0,257,256,1,0,0,
        0,257,258,1,0,0,0,258,259,1,0,0,0,259,260,5,2,0,0,260,39,1,0,0,0,
        261,262,5,26,0,0,262,263,3,54,27,0,263,267,5,8,0,0,264,266,3,2,1,
        0,265,264,1,0,0,0,266,269,1,0,0,0,267,265,1,0,0,0,267,268,1,0,0,
        0,268,41,1,0,0,0,269,267,1,0,0,0,270,271,5,27,0,0,271,275,5,8,0,
        0,272,274,3,2,1,0,273,272,1,0,0,0,274,277,1,0,0,0,275,273,1,0,0,
        0,275,276,1,0,0,0,276,43,1,0,0,0,277,275,1,0,0,0,278,279,5,28,0,
        0,279,280,5,60,0,0,280,282,5,11,0,0,281,283,3,46,23,0,282,281,1,
        0,0,0,282,283,1,0,0,0,283,284,1,0,0,0,284,287,5,12,0,0,285,286,5,
        8,0,0,286,288,3,88,44,0,287,285,1,0,0,0,287,288,1,0,0,0,288,289,
        1,0,0,0,289,290,3,4,2,0,290,45,1,0,0,0,291,296,3,48,24,0,292,293,
        5,29,0,0,293,295,3,48,24,0,294,292,1,0,0,0,295,298,1,0,0,0,296,294,
        1,0,0,0,296,297,1,0,0,0,297,47,1,0,0,0,298,296,1,0,0,0,299,302,5,
        60,0,0,300,301,5,8,0,0,301,303,3,88,44,0,302,300,1,0,0,0,302,303,
        1,0,0,0,303,49,1,0,0,0,304,305,5,30,0,0,305,308,5,60,0,0,306,307,
        5,8,0,0,307,309,5,60,0,0,308,306,1,0,0,0,308,309,1,0,0,0,309,310,
        1,0,0,0,310,314,5,1,0,0,311,313,3,52,26,0,312,311,1,0,0,0,313,316,
        1,0,0,0,314,312,1,0,0,0,314,315,1,0,0,0,315,317,1,0,0,0,316,314,
        1,0,0,0,317,318,5,2,0,0,318,51,1,0,0,0,319,323,3,44,22,0,320,323,
        3,6,3,0,321,323,3,8,4,0,322,319,1,0,0,0,322,320,1,0,0,0,322,321,
        1,0,0,0,323,53,1,0,0,0,324,325,3,56,28,0,325,55,1,0,0,0,326,327,
        3,78,39,0,327,328,5,7,0,0,328,329,3,56,28,0,329,338,1,0,0,0,330,
        331,3,78,39,0,331,332,5,9,0,0,332,333,5,60,0,0,333,334,5,7,0,0,334,
        335,3,56,28,0,335,338,1,0,0,0,336,338,3,58,29,0,337,326,1,0,0,0,
        337,330,1,0,0,0,337,336,1,0,0,0,338,57,1,0,0,0,339,345,3,60,30,0,
        340,341,5,31,0,0,341,342,3,54,27,0,342,343,5,8,0,0,343,344,3,54,
        27,0,344,346,1,0,0,0,345,340,1,0,0,0,345,346,1,0,0,0,346,59,1,0,
        0,0,347,352,3,62,31,0,348,349,5,32,0,0,349,351,3,62,31,0,350,348,
        1,0,0,0,351,354,1,0,0,0,352,350,1,0,0,0,352,353,1,0,0,0,353,61,1,
        0,0,0,354,352,1,0,0,0,355,360,3,64,32,0,356,357,5,33,0,0,357,359,
        3,64,32,0,358,356,1,0,0,0,359,362,1,0,0,0,360,358,1,0,0,0,360,361,
        1,0,0,0,361,63,1,0,0,0,362,360,1,0,0,0,363,368,3,66,33,0,364,365,
        7,1,0,0,365,367,3,66,33,0,366,364,1,0,0,0,367,370,1,0,0,0,368,366,
        1,0,0,0,368,369,1,0,0,0,369,65,1,0,0,0,370,368,1,0,0,0,371,376,3,
        68,34,0,372,373,7,2,0,0,373,375,3,68,34,0,374,372,1,0,0,0,375,378,
        1,0,0,0,376,374,1,0,0,0,376,377,1,0,0,0,377,67,1,0,0,0,378,376,1,
        0,0,0,379,384,3,70,35,0,380,381,7,3,0,0,381,383,3,70,35,0,382,380,
        1,0,0,0,383,386,1,0,0,0,384,382,1,0,0,0,384,385,1,0,0,0,385,69,1,
        0,0,0,386,384,1,0,0,0,387,392,3,72,36,0,388,389,7,4,0,0,389,391,
        3,72,36,0,390,388,1,0,0,0,391,394,1,0,0,0,392,390,1,0,0,0,392,393,
        1,0,0,0,393,71,1,0,0,0,394,392,1,0,0,0,395,396,7,5,0,0,396,399,3,
        72,36,0,397,399,3,74,37,0,398,395,1,0,0,0,398,397,1,0,0,0,399,73,
        1,0,0,0,400,407,3,76,38,0,401,407,3,78,39,0,402,403,5,11,0,0,403,
        404,3,54,27,0,404,405,5,12,0,0,405,407,1,0,0,0,406,400,1,0,0,0,406,
        401,1,0,0,0,406,402,1,0,0,0,407,75,1,0,0,0,408,414,5,56,0,0,409,
        414,3,86,43,0,410,414,5,46,0,0,411,414,5,47,0,0,412,414,5,48,0,0,
        413,408,1,0,0,0,413,409,1,0,0,0,413,410,1,0,0,0,413,411,1,0,0,0,
        413,412,1,0,0,0,414,77,1,0,0,0,415,419,3,80,40,0,416,418,3,82,41,
        0,417,416,1,0,0,0,418,421,1,0,0,0,419,417,1,0,0,0,419,420,1,0,0,
        0,420,79,1,0,0,0,421,419,1,0,0,0,422,432,5,60,0,0,423,424,5,49,0,
        0,424,425,5,60,0,0,425,427,5,11,0,0,426,428,3,84,42,0,427,426,1,
        0,0,0,427,428,1,0,0,0,428,429,1,0,0,0,429,432,5,12,0,0,430,432,5,
        50,0,0,431,422,1,0,0,0,431,423,1,0,0,0,431,430,1,0,0,0,432,81,1,
        0,0,0,433,435,5,11,0,0,434,436,3,84,42,0,435,434,1,0,0,0,435,436,
        1,0,0,0,436,437,1,0,0,0,437,445,5,12,0,0,438,439,5,51,0,0,439,440,
        3,54,27,0,440,441,5,52,0,0,441,445,1,0,0,0,442,443,5,9,0,0,443,445,
        5,60,0,0,444,433,1,0,0,0,444,438,1,0,0,0,444,442,1,0,0,0,445,83,
        1,0,0,0,446,451,3,54,27,0,447,448,5,29,0,0,448,450,3,54,27,0,449,
        447,1,0,0,0,450,453,1,0,0,0,451,449,1,0,0,0,451,452,1,0,0,0,452,
        85,1,0,0,0,453,451,1,0,0,0,454,463,5,51,0,0,455,460,3,54,27,0,456,
        457,5,29,0,0,457,459,3,54,27,0,458,456,1,0,0,0,459,462,1,0,0,0,460,
        458,1,0,0,0,460,461,1,0,0,0,461,464,1,0,0,0,462,460,1,0,0,0,463,
        455,1,0,0,0,463,464,1,0,0,0,464,465,1,0,0,0,465,466,5,52,0,0,466,
        87,1,0,0,0,467,472,3,90,45,0,468,469,5,51,0,0,469,471,5,52,0,0,470,
        468,1,0,0,0,471,474,1,0,0,0,472,470,1,0,0,0,472,473,1,0,0,0,473,
        89,1,0,0,0,474,472,1,0,0,0,475,476,7,6,0,0,476,91,1,0,0,0,43,95,
        118,124,132,135,142,166,184,205,208,212,233,253,257,267,275,282,
        287,296,302,308,314,322,337,345,352,360,368,376,384,392,398,406,
        413,419,427,431,435,444,451,460,463,472
    ]

class CompiscriptParser ( Parser ):

    grammarFileName = "Compiscript.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'{'", "'}'", "'let'", "'var'", "';'", 
                     "'const'", "'='", "':'", "'.'", "'print'", "'('", "')'", 
                     "'if'", "'else'", "'while'", "'do'", "'for'", "'foreach'", 
                     "'in'", "'break'", "'continue'", "'return'", "'try'", 
                     "'catch'", "'switch'", "'case'", "'default'", "'function'", 
                     "','", "'class'", "'?'", "'||'", "'&&'", "'=='", "'!='", 
                     "'<'", "'<='", "'>'", "'>='", "'+'", "'-'", "'*'", 
                     "'/'", "'%'", "'!'", "'null'", "'true'", "'false'", 
                     "'new'", "'this'", "'['", "']'", "'boolean'", "'integer'", 
                     "'string'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "Literal", "FloatLiteral", "IntegerLiteral", "StringLiteral", 
                      "Identifier", "WS", "COMMENT", "MULTILINE_COMMENT" ]

    RULE_program = 0
    RULE_statement = 1
    RULE_block = 2
    RULE_variableDeclaration = 3
    RULE_constantDeclaration = 4
    RULE_typeAnnotation = 5
    RULE_initializer = 6
    RULE_assignment = 7
    RULE_expressionStatement = 8
    RULE_printStatement = 9
    RULE_ifStatement = 10
    RULE_whileStatement = 11
    RULE_doWhileStatement = 12
    RULE_forStatement = 13
    RULE_foreachStatement = 14
    RULE_breakStatement = 15
    RULE_continueStatement = 16
    RULE_returnStatement = 17
    RULE_tryCatchStatement = 18
    RULE_switchStatement = 19
    RULE_switchCase = 20
    RULE_defaultCase = 21
    RULE_functionDeclaration = 22
    RULE_parameters = 23
    RULE_parameter = 24
    RULE_classDeclaration = 25
    RULE_classMember = 26
    RULE_expression = 27
    RULE_assignmentExpr = 28
    RULE_conditionalExpr = 29
    RULE_logicalOrExpr = 30
    RULE_logicalAndExpr = 31
    RULE_equalityExpr = 32
    RULE_relationalExpr = 33
    RULE_additiveExpr = 34
    RULE_multiplicativeExpr = 35
    RULE_unaryExpr = 36
    RULE_primaryExpr = 37
    RULE_literalExpr = 38
    RULE_leftHandSide = 39
    RULE_primaryAtom = 40
    RULE_suffixOp = 41
    RULE_arguments = 42
    RULE_arrayLiteral = 43
    RULE_type = 44
    RULE_baseType = 45

    ruleNames =  [ "program", "statement", "block", "variableDeclaration", 
                   "constantDeclaration", "typeAnnotation", "initializer", 
                   "assignment", "expressionStatement", "printStatement", 
                   "ifStatement", "whileStatement", "doWhileStatement", 
                   "forStatement", "foreachStatement", "breakStatement", 
                   "continueStatement", "returnStatement", "tryCatchStatement", 
                   "switchStatement", "switchCase", "defaultCase", "functionDeclaration", 
                   "parameters", "parameter", "classDeclaration", "classMember", 
                   "expression", "assignmentExpr", "conditionalExpr", "logicalOrExpr", 
                   "logicalAndExpr", "equalityExpr", "relationalExpr", "additiveExpr", 
                   "multiplicativeExpr", "unaryExpr", "primaryExpr", "literalExpr", 
                   "leftHandSide", "primaryAtom", "suffixOp", "arguments", 
                   "arrayLiteral", "type", "baseType" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    T__11=12
    T__12=13
    T__13=14
    T__14=15
    T__15=16
    T__16=17
    T__17=18
    T__18=19
    T__19=20
    T__20=21
    T__21=22
    T__22=23
    T__23=24
    T__24=25
    T__25=26
    T__26=27
    T__27=28
    T__28=29
    T__29=30
    T__30=31
    T__31=32
    T__32=33
    T__33=34
    T__34=35
    T__35=36
    T__36=37
    T__37=38
    T__38=39
    T__39=40
    T__40=41
    T__41=42
    T__42=43
    T__43=44
    T__44=45
    T__45=46
    T__46=47
    T__47=48
    T__48=49
    T__49=50
    T__50=51
    T__51=52
    T__52=53
    T__53=54
    T__54=55
    Literal=56
    FloatLiteral=57
    IntegerLiteral=58
    StringLiteral=59
    Identifier=60
    WS=61
    COMMENT=62
    MULTILINE_COMMENT=63

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgramContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(CompiscriptParser.EOF, 0)

        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CompiscriptParser.StatementContext)
            else:
                return self.getTypedRuleContext(CompiscriptParser.StatementContext,i)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_program

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProgram" ):
                listener.enterProgram(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProgram" ):
                listener.exitProgram(self)




    def program(self):

        localctx = CompiscriptParser.ProgramContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_program)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 95
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 1229449714315275354) != 0):
                self.state = 92
                self.statement()
                self.state = 97
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 98
            self.match(CompiscriptParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def variableDeclaration(self):
            return self.getTypedRuleContext(CompiscriptParser.VariableDeclarationContext,0)


        def constantDeclaration(self):
            return self.getTypedRuleContext(CompiscriptParser.ConstantDeclarationContext,0)


        def assignment(self):
            return self.getTypedRuleContext(CompiscriptParser.AssignmentContext,0)


        def functionDeclaration(self):
            return self.getTypedRuleContext(CompiscriptParser.FunctionDeclarationContext,0)


        def classDeclaration(self):
            return self.getTypedRuleContext(CompiscriptParser.ClassDeclarationContext,0)


        def expressionStatement(self):
            return self.getTypedRuleContext(CompiscriptParser.ExpressionStatementContext,0)


        def printStatement(self):
            return self.getTypedRuleContext(CompiscriptParser.PrintStatementContext,0)


        def block(self):
            return self.getTypedRuleContext(CompiscriptParser.BlockContext,0)


        def ifStatement(self):
            return self.getTypedRuleContext(CompiscriptParser.IfStatementContext,0)


        def whileStatement(self):
            return self.getTypedRuleContext(CompiscriptParser.WhileStatementContext,0)


        def doWhileStatement(self):
            return self.getTypedRuleContext(CompiscriptParser.DoWhileStatementContext,0)


        def forStatement(self):
            return self.getTypedRuleContext(CompiscriptParser.ForStatementContext,0)


        def foreachStatement(self):
            return self.getTypedRuleContext(CompiscriptParser.ForeachStatementContext,0)


        def tryCatchStatement(self):
            return self.getTypedRuleContext(CompiscriptParser.TryCatchStatementContext,0)


        def switchStatement(self):
            return self.getTypedRuleContext(CompiscriptParser.SwitchStatementContext,0)


        def breakStatement(self):
            return self.getTypedRuleContext(CompiscriptParser.BreakStatementContext,0)


        def continueStatement(self):
            return self.getTypedRuleContext(CompiscriptParser.ContinueStatementContext,0)


        def returnStatement(self):
            return self.getTypedRuleContext(CompiscriptParser.ReturnStatementContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStatement" ):
                listener.enterStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStatement" ):
                listener.exitStatement(self)




    def statement(self):

        localctx = CompiscriptParser.StatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_statement)
        try:
            self.state = 118
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 100
                self.variableDeclaration()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 101
                self.constantDeclaration()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 102
                self.assignment()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 103
                self.functionDeclaration()
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 104
                self.classDeclaration()
                pass

            elif la_ == 6:
                self.enterOuterAlt(localctx, 6)
                self.state = 105
                self.expressionStatement()
                pass

            elif la_ == 7:
                self.enterOuterAlt(localctx, 7)
                self.state = 106
                self.printStatement()
                pass

            elif la_ == 8:
                self.enterOuterAlt(localctx, 8)
                self.state = 107
                self.block()
                pass

            elif la_ == 9:
                self.enterOuterAlt(localctx, 9)
                self.state = 108
                self.ifStatement()
                pass

            elif la_ == 10:
                self.enterOuterAlt(localctx, 10)
                self.state = 109
                self.whileStatement()
                pass

            elif la_ == 11:
                self.enterOuterAlt(localctx, 11)
                self.state = 110
                self.doWhileStatement()
                pass

            elif la_ == 12:
                self.enterOuterAlt(localctx, 12)
                self.state = 111
                self.forStatement()
                pass

            elif la_ == 13:
                self.enterOuterAlt(localctx, 13)
                self.state = 112
                self.foreachStatement()
                pass

            elif la_ == 14:
                self.enterOuterAlt(localctx, 14)
                self.state = 113
                self.tryCatchStatement()
                pass

            elif la_ == 15:
                self.enterOuterAlt(localctx, 15)
                self.state = 114
                self.switchStatement()
                pass

            elif la_ == 16:
                self.enterOuterAlt(localctx, 16)
                self.state = 115
                self.breakStatement()
                pass

            elif la_ == 17:
                self.enterOuterAlt(localctx, 17)
                self.state = 116
                self.continueStatement()
                pass

            elif la_ == 18:
                self.enterOuterAlt(localctx, 18)
                self.state = 117
                self.returnStatement()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BlockContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CompiscriptParser.StatementContext)
            else:
                return self.getTypedRuleContext(CompiscriptParser.StatementContext,i)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_block

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBlock" ):
                listener.enterBlock(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBlock" ):
                listener.exitBlock(self)




    def block(self):

        localctx = CompiscriptParser.BlockContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_block)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 120
            self.match(CompiscriptParser.T__0)
            self.state = 124
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 1229449714315275354) != 0):
                self.state = 121
                self.statement()
                self.state = 126
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 127
            self.match(CompiscriptParser.T__1)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class VariableDeclarationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Identifier(self):
            return self.getToken(CompiscriptParser.Identifier, 0)

        def typeAnnotation(self):
            return self.getTypedRuleContext(CompiscriptParser.TypeAnnotationContext,0)


        def initializer(self):
            return self.getTypedRuleContext(CompiscriptParser.InitializerContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_variableDeclaration

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVariableDeclaration" ):
                listener.enterVariableDeclaration(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVariableDeclaration" ):
                listener.exitVariableDeclaration(self)




    def variableDeclaration(self):

        localctx = CompiscriptParser.VariableDeclarationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_variableDeclaration)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 129
            _la = self._input.LA(1)
            if not(_la==3 or _la==4):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 130
            self.match(CompiscriptParser.Identifier)
            self.state = 132
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==8:
                self.state = 131
                self.typeAnnotation()


            self.state = 135
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==7:
                self.state = 134
                self.initializer()


            self.state = 137
            self.match(CompiscriptParser.T__4)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConstantDeclarationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Identifier(self):
            return self.getToken(CompiscriptParser.Identifier, 0)

        def expression(self):
            return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,0)


        def typeAnnotation(self):
            return self.getTypedRuleContext(CompiscriptParser.TypeAnnotationContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_constantDeclaration

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterConstantDeclaration" ):
                listener.enterConstantDeclaration(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitConstantDeclaration" ):
                listener.exitConstantDeclaration(self)




    def constantDeclaration(self):

        localctx = CompiscriptParser.ConstantDeclarationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_constantDeclaration)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 139
            self.match(CompiscriptParser.T__5)
            self.state = 140
            self.match(CompiscriptParser.Identifier)
            self.state = 142
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==8:
                self.state = 141
                self.typeAnnotation()


            self.state = 144
            self.match(CompiscriptParser.T__6)
            self.state = 145
            self.expression()
            self.state = 146
            self.match(CompiscriptParser.T__4)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TypeAnnotationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def type_(self):
            return self.getTypedRuleContext(CompiscriptParser.TypeContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_typeAnnotation

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTypeAnnotation" ):
                listener.enterTypeAnnotation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTypeAnnotation" ):
                listener.exitTypeAnnotation(self)




    def typeAnnotation(self):

        localctx = CompiscriptParser.TypeAnnotationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_typeAnnotation)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 148
            self.match(CompiscriptParser.T__7)
            self.state = 149
            self.type_()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InitializerContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self):
            return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_initializer

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInitializer" ):
                listener.enterInitializer(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInitializer" ):
                listener.exitInitializer(self)




    def initializer(self):

        localctx = CompiscriptParser.InitializerContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_initializer)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 151
            self.match(CompiscriptParser.T__6)
            self.state = 152
            self.expression()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AssignmentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Identifier(self):
            return self.getToken(CompiscriptParser.Identifier, 0)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CompiscriptParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,i)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_assignment

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAssignment" ):
                listener.enterAssignment(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAssignment" ):
                listener.exitAssignment(self)




    def assignment(self):

        localctx = CompiscriptParser.AssignmentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_assignment)
        try:
            self.state = 166
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,6,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 154
                self.match(CompiscriptParser.Identifier)
                self.state = 155
                self.match(CompiscriptParser.T__6)
                self.state = 156
                self.expression()
                self.state = 157
                self.match(CompiscriptParser.T__4)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 159
                self.expression()
                self.state = 160
                self.match(CompiscriptParser.T__8)
                self.state = 161
                self.match(CompiscriptParser.Identifier)
                self.state = 162
                self.match(CompiscriptParser.T__6)
                self.state = 163
                self.expression()
                self.state = 164
                self.match(CompiscriptParser.T__4)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressionStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self):
            return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_expressionStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpressionStatement" ):
                listener.enterExpressionStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpressionStatement" ):
                listener.exitExpressionStatement(self)




    def expressionStatement(self):

        localctx = CompiscriptParser.ExpressionStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_expressionStatement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 168
            self.expression()
            self.state = 169
            self.match(CompiscriptParser.T__4)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PrintStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self):
            return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_printStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrintStatement" ):
                listener.enterPrintStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrintStatement" ):
                listener.exitPrintStatement(self)




    def printStatement(self):

        localctx = CompiscriptParser.PrintStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_printStatement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 171
            self.match(CompiscriptParser.T__9)
            self.state = 172
            self.match(CompiscriptParser.T__10)
            self.state = 173
            self.expression()
            self.state = 174
            self.match(CompiscriptParser.T__11)
            self.state = 175
            self.match(CompiscriptParser.T__4)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IfStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self):
            return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,0)


        def block(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CompiscriptParser.BlockContext)
            else:
                return self.getTypedRuleContext(CompiscriptParser.BlockContext,i)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_ifStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIfStatement" ):
                listener.enterIfStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIfStatement" ):
                listener.exitIfStatement(self)




    def ifStatement(self):

        localctx = CompiscriptParser.IfStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_ifStatement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 177
            self.match(CompiscriptParser.T__12)
            self.state = 178
            self.match(CompiscriptParser.T__10)
            self.state = 179
            self.expression()
            self.state = 180
            self.match(CompiscriptParser.T__11)
            self.state = 181
            self.block()
            self.state = 184
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==14:
                self.state = 182
                self.match(CompiscriptParser.T__13)
                self.state = 183
                self.block()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class WhileStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self):
            return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,0)


        def block(self):
            return self.getTypedRuleContext(CompiscriptParser.BlockContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_whileStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterWhileStatement" ):
                listener.enterWhileStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitWhileStatement" ):
                listener.exitWhileStatement(self)




    def whileStatement(self):

        localctx = CompiscriptParser.WhileStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_whileStatement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 186
            self.match(CompiscriptParser.T__14)
            self.state = 187
            self.match(CompiscriptParser.T__10)
            self.state = 188
            self.expression()
            self.state = 189
            self.match(CompiscriptParser.T__11)
            self.state = 190
            self.block()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DoWhileStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def block(self):
            return self.getTypedRuleContext(CompiscriptParser.BlockContext,0)


        def expression(self):
            return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_doWhileStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDoWhileStatement" ):
                listener.enterDoWhileStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDoWhileStatement" ):
                listener.exitDoWhileStatement(self)




    def doWhileStatement(self):

        localctx = CompiscriptParser.DoWhileStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_doWhileStatement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 192
            self.match(CompiscriptParser.T__15)
            self.state = 193
            self.block()
            self.state = 194
            self.match(CompiscriptParser.T__14)
            self.state = 195
            self.match(CompiscriptParser.T__10)
            self.state = 196
            self.expression()
            self.state = 197
            self.match(CompiscriptParser.T__11)
            self.state = 198
            self.match(CompiscriptParser.T__4)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ForStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def block(self):
            return self.getTypedRuleContext(CompiscriptParser.BlockContext,0)


        def variableDeclaration(self):
            return self.getTypedRuleContext(CompiscriptParser.VariableDeclarationContext,0)


        def assignment(self):
            return self.getTypedRuleContext(CompiscriptParser.AssignmentContext,0)


        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CompiscriptParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,i)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_forStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterForStatement" ):
                listener.enterForStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitForStatement" ):
                listener.exitForStatement(self)




    def forStatement(self):

        localctx = CompiscriptParser.ForStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_forStatement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 200
            self.match(CompiscriptParser.T__16)
            self.state = 201
            self.match(CompiscriptParser.T__10)
            self.state = 205
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [3, 4]:
                self.state = 202
                self.variableDeclaration()
                pass
            elif token in [11, 41, 45, 46, 47, 48, 49, 50, 51, 56, 60]:
                self.state = 203
                self.assignment()
                pass
            elif token in [5]:
                self.state = 204
                self.match(CompiscriptParser.T__4)
                pass
            else:
                raise NoViableAltException(self)

            self.state = 208
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 1229449712923314176) != 0):
                self.state = 207
                self.expression()


            self.state = 210
            self.match(CompiscriptParser.T__4)
            self.state = 212
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 1229449712923314176) != 0):
                self.state = 211
                self.expression()


            self.state = 214
            self.match(CompiscriptParser.T__11)
            self.state = 215
            self.block()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ForeachStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Identifier(self):
            return self.getToken(CompiscriptParser.Identifier, 0)

        def expression(self):
            return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,0)


        def block(self):
            return self.getTypedRuleContext(CompiscriptParser.BlockContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_foreachStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterForeachStatement" ):
                listener.enterForeachStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitForeachStatement" ):
                listener.exitForeachStatement(self)




    def foreachStatement(self):

        localctx = CompiscriptParser.ForeachStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_foreachStatement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 217
            self.match(CompiscriptParser.T__17)
            self.state = 218
            self.match(CompiscriptParser.T__10)
            self.state = 219
            self.match(CompiscriptParser.Identifier)
            self.state = 220
            self.match(CompiscriptParser.T__18)
            self.state = 221
            self.expression()
            self.state = 222
            self.match(CompiscriptParser.T__11)
            self.state = 223
            self.block()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BreakStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return CompiscriptParser.RULE_breakStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBreakStatement" ):
                listener.enterBreakStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBreakStatement" ):
                listener.exitBreakStatement(self)




    def breakStatement(self):

        localctx = CompiscriptParser.BreakStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_breakStatement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 225
            self.match(CompiscriptParser.T__19)
            self.state = 226
            self.match(CompiscriptParser.T__4)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ContinueStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return CompiscriptParser.RULE_continueStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterContinueStatement" ):
                listener.enterContinueStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitContinueStatement" ):
                listener.exitContinueStatement(self)




    def continueStatement(self):

        localctx = CompiscriptParser.ContinueStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_continueStatement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 228
            self.match(CompiscriptParser.T__20)
            self.state = 229
            self.match(CompiscriptParser.T__4)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ReturnStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self):
            return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_returnStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterReturnStatement" ):
                listener.enterReturnStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitReturnStatement" ):
                listener.exitReturnStatement(self)




    def returnStatement(self):

        localctx = CompiscriptParser.ReturnStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_returnStatement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 231
            self.match(CompiscriptParser.T__21)
            self.state = 233
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 1229449712923314176) != 0):
                self.state = 232
                self.expression()


            self.state = 235
            self.match(CompiscriptParser.T__4)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TryCatchStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def block(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CompiscriptParser.BlockContext)
            else:
                return self.getTypedRuleContext(CompiscriptParser.BlockContext,i)


        def Identifier(self):
            return self.getToken(CompiscriptParser.Identifier, 0)

        def getRuleIndex(self):
            return CompiscriptParser.RULE_tryCatchStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTryCatchStatement" ):
                listener.enterTryCatchStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTryCatchStatement" ):
                listener.exitTryCatchStatement(self)




    def tryCatchStatement(self):

        localctx = CompiscriptParser.TryCatchStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_tryCatchStatement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 237
            self.match(CompiscriptParser.T__22)
            self.state = 238
            self.block()
            self.state = 239
            self.match(CompiscriptParser.T__23)
            self.state = 240
            self.match(CompiscriptParser.T__10)
            self.state = 241
            self.match(CompiscriptParser.Identifier)
            self.state = 242
            self.match(CompiscriptParser.T__11)
            self.state = 243
            self.block()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SwitchStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self):
            return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,0)


        def switchCase(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CompiscriptParser.SwitchCaseContext)
            else:
                return self.getTypedRuleContext(CompiscriptParser.SwitchCaseContext,i)


        def defaultCase(self):
            return self.getTypedRuleContext(CompiscriptParser.DefaultCaseContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_switchStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSwitchStatement" ):
                listener.enterSwitchStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSwitchStatement" ):
                listener.exitSwitchStatement(self)




    def switchStatement(self):

        localctx = CompiscriptParser.SwitchStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_switchStatement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 245
            self.match(CompiscriptParser.T__24)
            self.state = 246
            self.match(CompiscriptParser.T__10)
            self.state = 247
            self.expression()
            self.state = 248
            self.match(CompiscriptParser.T__11)
            self.state = 249
            self.match(CompiscriptParser.T__0)
            self.state = 253
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==26:
                self.state = 250
                self.switchCase()
                self.state = 255
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 257
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==27:
                self.state = 256
                self.defaultCase()


            self.state = 259
            self.match(CompiscriptParser.T__1)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SwitchCaseContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self):
            return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,0)


        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CompiscriptParser.StatementContext)
            else:
                return self.getTypedRuleContext(CompiscriptParser.StatementContext,i)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_switchCase

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSwitchCase" ):
                listener.enterSwitchCase(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSwitchCase" ):
                listener.exitSwitchCase(self)




    def switchCase(self):

        localctx = CompiscriptParser.SwitchCaseContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_switchCase)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 261
            self.match(CompiscriptParser.T__25)
            self.state = 262
            self.expression()
            self.state = 263
            self.match(CompiscriptParser.T__7)
            self.state = 267
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 1229449714315275354) != 0):
                self.state = 264
                self.statement()
                self.state = 269
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DefaultCaseContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CompiscriptParser.StatementContext)
            else:
                return self.getTypedRuleContext(CompiscriptParser.StatementContext,i)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_defaultCase

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDefaultCase" ):
                listener.enterDefaultCase(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDefaultCase" ):
                listener.exitDefaultCase(self)




    def defaultCase(self):

        localctx = CompiscriptParser.DefaultCaseContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_defaultCase)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 270
            self.match(CompiscriptParser.T__26)
            self.state = 271
            self.match(CompiscriptParser.T__7)
            self.state = 275
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 1229449714315275354) != 0):
                self.state = 272
                self.statement()
                self.state = 277
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FunctionDeclarationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Identifier(self):
            return self.getToken(CompiscriptParser.Identifier, 0)

        def block(self):
            return self.getTypedRuleContext(CompiscriptParser.BlockContext,0)


        def parameters(self):
            return self.getTypedRuleContext(CompiscriptParser.ParametersContext,0)


        def type_(self):
            return self.getTypedRuleContext(CompiscriptParser.TypeContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_functionDeclaration

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunctionDeclaration" ):
                listener.enterFunctionDeclaration(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunctionDeclaration" ):
                listener.exitFunctionDeclaration(self)




    def functionDeclaration(self):

        localctx = CompiscriptParser.FunctionDeclarationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_functionDeclaration)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 278
            self.match(CompiscriptParser.T__27)
            self.state = 279
            self.match(CompiscriptParser.Identifier)
            self.state = 280
            self.match(CompiscriptParser.T__10)
            self.state = 282
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==60:
                self.state = 281
                self.parameters()


            self.state = 284
            self.match(CompiscriptParser.T__11)
            self.state = 287
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==8:
                self.state = 285
                self.match(CompiscriptParser.T__7)
                self.state = 286
                self.type_()


            self.state = 289
            self.block()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParametersContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def parameter(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CompiscriptParser.ParameterContext)
            else:
                return self.getTypedRuleContext(CompiscriptParser.ParameterContext,i)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_parameters

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParameters" ):
                listener.enterParameters(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParameters" ):
                listener.exitParameters(self)




    def parameters(self):

        localctx = CompiscriptParser.ParametersContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_parameters)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 291
            self.parameter()
            self.state = 296
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==29:
                self.state = 292
                self.match(CompiscriptParser.T__28)
                self.state = 293
                self.parameter()
                self.state = 298
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParameterContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Identifier(self):
            return self.getToken(CompiscriptParser.Identifier, 0)

        def type_(self):
            return self.getTypedRuleContext(CompiscriptParser.TypeContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_parameter

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParameter" ):
                listener.enterParameter(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParameter" ):
                listener.exitParameter(self)




    def parameter(self):

        localctx = CompiscriptParser.ParameterContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_parameter)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 299
            self.match(CompiscriptParser.Identifier)
            self.state = 302
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==8:
                self.state = 300
                self.match(CompiscriptParser.T__7)
                self.state = 301
                self.type_()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ClassDeclarationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Identifier(self, i:int=None):
            if i is None:
                return self.getTokens(CompiscriptParser.Identifier)
            else:
                return self.getToken(CompiscriptParser.Identifier, i)

        def classMember(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CompiscriptParser.ClassMemberContext)
            else:
                return self.getTypedRuleContext(CompiscriptParser.ClassMemberContext,i)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_classDeclaration

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterClassDeclaration" ):
                listener.enterClassDeclaration(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitClassDeclaration" ):
                listener.exitClassDeclaration(self)




    def classDeclaration(self):

        localctx = CompiscriptParser.ClassDeclarationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_classDeclaration)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 304
            self.match(CompiscriptParser.T__29)
            self.state = 305
            self.match(CompiscriptParser.Identifier)
            self.state = 308
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==8:
                self.state = 306
                self.match(CompiscriptParser.T__7)
                self.state = 307
                self.match(CompiscriptParser.Identifier)


            self.state = 310
            self.match(CompiscriptParser.T__0)
            self.state = 314
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 268435544) != 0):
                self.state = 311
                self.classMember()
                self.state = 316
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 317
            self.match(CompiscriptParser.T__1)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ClassMemberContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def functionDeclaration(self):
            return self.getTypedRuleContext(CompiscriptParser.FunctionDeclarationContext,0)


        def variableDeclaration(self):
            return self.getTypedRuleContext(CompiscriptParser.VariableDeclarationContext,0)


        def constantDeclaration(self):
            return self.getTypedRuleContext(CompiscriptParser.ConstantDeclarationContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_classMember

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterClassMember" ):
                listener.enterClassMember(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitClassMember" ):
                listener.exitClassMember(self)




    def classMember(self):

        localctx = CompiscriptParser.ClassMemberContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_classMember)
        try:
            self.state = 322
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [28]:
                self.enterOuterAlt(localctx, 1)
                self.state = 319
                self.functionDeclaration()
                pass
            elif token in [3, 4]:
                self.enterOuterAlt(localctx, 2)
                self.state = 320
                self.variableDeclaration()
                pass
            elif token in [6]:
                self.enterOuterAlt(localctx, 3)
                self.state = 321
                self.constantDeclaration()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def assignmentExpr(self):
            return self.getTypedRuleContext(CompiscriptParser.AssignmentExprContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_expression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpression" ):
                listener.enterExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpression" ):
                listener.exitExpression(self)




    def expression(self):

        localctx = CompiscriptParser.ExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_expression)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 324
            self.assignmentExpr()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AssignmentExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return CompiscriptParser.RULE_assignmentExpr

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class ExprNoAssignContext(AssignmentExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CompiscriptParser.AssignmentExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def conditionalExpr(self):
            return self.getTypedRuleContext(CompiscriptParser.ConditionalExprContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExprNoAssign" ):
                listener.enterExprNoAssign(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExprNoAssign" ):
                listener.exitExprNoAssign(self)


    class PropertyAssignExprContext(AssignmentExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CompiscriptParser.AssignmentExprContext
            super().__init__(parser)
            self.lhs = None # LeftHandSideContext
            self.copyFrom(ctx)

        def Identifier(self):
            return self.getToken(CompiscriptParser.Identifier, 0)
        def assignmentExpr(self):
            return self.getTypedRuleContext(CompiscriptParser.AssignmentExprContext,0)

        def leftHandSide(self):
            return self.getTypedRuleContext(CompiscriptParser.LeftHandSideContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPropertyAssignExpr" ):
                listener.enterPropertyAssignExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPropertyAssignExpr" ):
                listener.exitPropertyAssignExpr(self)


    class AssignExprContext(AssignmentExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CompiscriptParser.AssignmentExprContext
            super().__init__(parser)
            self.lhs = None # LeftHandSideContext
            self.copyFrom(ctx)

        def assignmentExpr(self):
            return self.getTypedRuleContext(CompiscriptParser.AssignmentExprContext,0)

        def leftHandSide(self):
            return self.getTypedRuleContext(CompiscriptParser.LeftHandSideContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAssignExpr" ):
                listener.enterAssignExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAssignExpr" ):
                listener.exitAssignExpr(self)



    def assignmentExpr(self):

        localctx = CompiscriptParser.AssignmentExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_assignmentExpr)
        try:
            self.state = 337
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,23,self._ctx)
            if la_ == 1:
                localctx = CompiscriptParser.AssignExprContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 326
                localctx.lhs = self.leftHandSide()
                self.state = 327
                self.match(CompiscriptParser.T__6)
                self.state = 328
                self.assignmentExpr()
                pass

            elif la_ == 2:
                localctx = CompiscriptParser.PropertyAssignExprContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 330
                localctx.lhs = self.leftHandSide()
                self.state = 331
                self.match(CompiscriptParser.T__8)
                self.state = 332
                self.match(CompiscriptParser.Identifier)
                self.state = 333
                self.match(CompiscriptParser.T__6)
                self.state = 334
                self.assignmentExpr()
                pass

            elif la_ == 3:
                localctx = CompiscriptParser.ExprNoAssignContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 336
                self.conditionalExpr()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConditionalExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return CompiscriptParser.RULE_conditionalExpr

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class TernaryExprContext(ConditionalExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CompiscriptParser.ConditionalExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def logicalOrExpr(self):
            return self.getTypedRuleContext(CompiscriptParser.LogicalOrExprContext,0)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CompiscriptParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTernaryExpr" ):
                listener.enterTernaryExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTernaryExpr" ):
                listener.exitTernaryExpr(self)



    def conditionalExpr(self):

        localctx = CompiscriptParser.ConditionalExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_conditionalExpr)
        self._la = 0 # Token type
        try:
            localctx = CompiscriptParser.TernaryExprContext(self, localctx)
            self.enterOuterAlt(localctx, 1)
            self.state = 339
            self.logicalOrExpr()
            self.state = 345
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==31:
                self.state = 340
                self.match(CompiscriptParser.T__30)
                self.state = 341
                self.expression()
                self.state = 342
                self.match(CompiscriptParser.T__7)
                self.state = 343
                self.expression()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LogicalOrExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def logicalAndExpr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CompiscriptParser.LogicalAndExprContext)
            else:
                return self.getTypedRuleContext(CompiscriptParser.LogicalAndExprContext,i)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_logicalOrExpr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLogicalOrExpr" ):
                listener.enterLogicalOrExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLogicalOrExpr" ):
                listener.exitLogicalOrExpr(self)




    def logicalOrExpr(self):

        localctx = CompiscriptParser.LogicalOrExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_logicalOrExpr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 347
            self.logicalAndExpr()
            self.state = 352
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==32:
                self.state = 348
                self.match(CompiscriptParser.T__31)
                self.state = 349
                self.logicalAndExpr()
                self.state = 354
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LogicalAndExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def equalityExpr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CompiscriptParser.EqualityExprContext)
            else:
                return self.getTypedRuleContext(CompiscriptParser.EqualityExprContext,i)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_logicalAndExpr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLogicalAndExpr" ):
                listener.enterLogicalAndExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLogicalAndExpr" ):
                listener.exitLogicalAndExpr(self)




    def logicalAndExpr(self):

        localctx = CompiscriptParser.LogicalAndExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_logicalAndExpr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 355
            self.equalityExpr()
            self.state = 360
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==33:
                self.state = 356
                self.match(CompiscriptParser.T__32)
                self.state = 357
                self.equalityExpr()
                self.state = 362
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EqualityExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def relationalExpr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CompiscriptParser.RelationalExprContext)
            else:
                return self.getTypedRuleContext(CompiscriptParser.RelationalExprContext,i)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_equalityExpr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEqualityExpr" ):
                listener.enterEqualityExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEqualityExpr" ):
                listener.exitEqualityExpr(self)




    def equalityExpr(self):

        localctx = CompiscriptParser.EqualityExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_equalityExpr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 363
            self.relationalExpr()
            self.state = 368
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==34 or _la==35:
                self.state = 364
                _la = self._input.LA(1)
                if not(_la==34 or _la==35):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 365
                self.relationalExpr()
                self.state = 370
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RelationalExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def additiveExpr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CompiscriptParser.AdditiveExprContext)
            else:
                return self.getTypedRuleContext(CompiscriptParser.AdditiveExprContext,i)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_relationalExpr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRelationalExpr" ):
                listener.enterRelationalExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRelationalExpr" ):
                listener.exitRelationalExpr(self)




    def relationalExpr(self):

        localctx = CompiscriptParser.RelationalExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_relationalExpr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 371
            self.additiveExpr()
            self.state = 376
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 1030792151040) != 0):
                self.state = 372
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 1030792151040) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 373
                self.additiveExpr()
                self.state = 378
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AdditiveExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def multiplicativeExpr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CompiscriptParser.MultiplicativeExprContext)
            else:
                return self.getTypedRuleContext(CompiscriptParser.MultiplicativeExprContext,i)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_additiveExpr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAdditiveExpr" ):
                listener.enterAdditiveExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAdditiveExpr" ):
                listener.exitAdditiveExpr(self)




    def additiveExpr(self):

        localctx = CompiscriptParser.AdditiveExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 68, self.RULE_additiveExpr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 379
            self.multiplicativeExpr()
            self.state = 384
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==40 or _la==41:
                self.state = 380
                _la = self._input.LA(1)
                if not(_la==40 or _la==41):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 381
                self.multiplicativeExpr()
                self.state = 386
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MultiplicativeExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def unaryExpr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CompiscriptParser.UnaryExprContext)
            else:
                return self.getTypedRuleContext(CompiscriptParser.UnaryExprContext,i)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_multiplicativeExpr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMultiplicativeExpr" ):
                listener.enterMultiplicativeExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMultiplicativeExpr" ):
                listener.exitMultiplicativeExpr(self)




    def multiplicativeExpr(self):

        localctx = CompiscriptParser.MultiplicativeExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 70, self.RULE_multiplicativeExpr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 387
            self.unaryExpr()
            self.state = 392
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 30786325577728) != 0):
                self.state = 388
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 30786325577728) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 389
                self.unaryExpr()
                self.state = 394
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class UnaryExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def unaryExpr(self):
            return self.getTypedRuleContext(CompiscriptParser.UnaryExprContext,0)


        def primaryExpr(self):
            return self.getTypedRuleContext(CompiscriptParser.PrimaryExprContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_unaryExpr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUnaryExpr" ):
                listener.enterUnaryExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUnaryExpr" ):
                listener.exitUnaryExpr(self)




    def unaryExpr(self):

        localctx = CompiscriptParser.UnaryExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 72, self.RULE_unaryExpr)
        self._la = 0 # Token type
        try:
            self.state = 398
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [41, 45]:
                self.enterOuterAlt(localctx, 1)
                self.state = 395
                _la = self._input.LA(1)
                if not(_la==41 or _la==45):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 396
                self.unaryExpr()
                pass
            elif token in [11, 46, 47, 48, 49, 50, 51, 56, 60]:
                self.enterOuterAlt(localctx, 2)
                self.state = 397
                self.primaryExpr()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PrimaryExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def literalExpr(self):
            return self.getTypedRuleContext(CompiscriptParser.LiteralExprContext,0)


        def leftHandSide(self):
            return self.getTypedRuleContext(CompiscriptParser.LeftHandSideContext,0)


        def expression(self):
            return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_primaryExpr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrimaryExpr" ):
                listener.enterPrimaryExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrimaryExpr" ):
                listener.exitPrimaryExpr(self)




    def primaryExpr(self):

        localctx = CompiscriptParser.PrimaryExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 74, self.RULE_primaryExpr)
        try:
            self.state = 406
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [46, 47, 48, 51, 56]:
                self.enterOuterAlt(localctx, 1)
                self.state = 400
                self.literalExpr()
                pass
            elif token in [49, 50, 60]:
                self.enterOuterAlt(localctx, 2)
                self.state = 401
                self.leftHandSide()
                pass
            elif token in [11]:
                self.enterOuterAlt(localctx, 3)
                self.state = 402
                self.match(CompiscriptParser.T__10)
                self.state = 403
                self.expression()
                self.state = 404
                self.match(CompiscriptParser.T__11)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LiteralExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Literal(self):
            return self.getToken(CompiscriptParser.Literal, 0)

        def arrayLiteral(self):
            return self.getTypedRuleContext(CompiscriptParser.ArrayLiteralContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_literalExpr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLiteralExpr" ):
                listener.enterLiteralExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLiteralExpr" ):
                listener.exitLiteralExpr(self)




    def literalExpr(self):

        localctx = CompiscriptParser.LiteralExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 76, self.RULE_literalExpr)
        try:
            self.state = 413
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [56]:
                self.enterOuterAlt(localctx, 1)
                self.state = 408
                self.match(CompiscriptParser.Literal)
                pass
            elif token in [51]:
                self.enterOuterAlt(localctx, 2)
                self.state = 409
                self.arrayLiteral()
                pass
            elif token in [46]:
                self.enterOuterAlt(localctx, 3)
                self.state = 410
                self.match(CompiscriptParser.T__45)
                pass
            elif token in [47]:
                self.enterOuterAlt(localctx, 4)
                self.state = 411
                self.match(CompiscriptParser.T__46)
                pass
            elif token in [48]:
                self.enterOuterAlt(localctx, 5)
                self.state = 412
                self.match(CompiscriptParser.T__47)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LeftHandSideContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def primaryAtom(self):
            return self.getTypedRuleContext(CompiscriptParser.PrimaryAtomContext,0)


        def suffixOp(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CompiscriptParser.SuffixOpContext)
            else:
                return self.getTypedRuleContext(CompiscriptParser.SuffixOpContext,i)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_leftHandSide

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLeftHandSide" ):
                listener.enterLeftHandSide(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLeftHandSide" ):
                listener.exitLeftHandSide(self)




    def leftHandSide(self):

        localctx = CompiscriptParser.LeftHandSideContext(self, self._ctx, self.state)
        self.enterRule(localctx, 78, self.RULE_leftHandSide)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 415
            self.primaryAtom()
            self.state = 419
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,34,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 416
                    self.suffixOp() 
                self.state = 421
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,34,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PrimaryAtomContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return CompiscriptParser.RULE_primaryAtom

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class IdentifierExprContext(PrimaryAtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CompiscriptParser.PrimaryAtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Identifier(self):
            return self.getToken(CompiscriptParser.Identifier, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIdentifierExpr" ):
                listener.enterIdentifierExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIdentifierExpr" ):
                listener.exitIdentifierExpr(self)


    class NewExprContext(PrimaryAtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CompiscriptParser.PrimaryAtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Identifier(self):
            return self.getToken(CompiscriptParser.Identifier, 0)
        def arguments(self):
            return self.getTypedRuleContext(CompiscriptParser.ArgumentsContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNewExpr" ):
                listener.enterNewExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNewExpr" ):
                listener.exitNewExpr(self)


    class ThisExprContext(PrimaryAtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CompiscriptParser.PrimaryAtomContext
            super().__init__(parser)
            self.copyFrom(ctx)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterThisExpr" ):
                listener.enterThisExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitThisExpr" ):
                listener.exitThisExpr(self)



    def primaryAtom(self):

        localctx = CompiscriptParser.PrimaryAtomContext(self, self._ctx, self.state)
        self.enterRule(localctx, 80, self.RULE_primaryAtom)
        self._la = 0 # Token type
        try:
            self.state = 431
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [60]:
                localctx = CompiscriptParser.IdentifierExprContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 422
                self.match(CompiscriptParser.Identifier)
                pass
            elif token in [49]:
                localctx = CompiscriptParser.NewExprContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 423
                self.match(CompiscriptParser.T__48)
                self.state = 424
                self.match(CompiscriptParser.Identifier)
                self.state = 425
                self.match(CompiscriptParser.T__10)
                self.state = 427
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & 1229449712923314176) != 0):
                    self.state = 426
                    self.arguments()


                self.state = 429
                self.match(CompiscriptParser.T__11)
                pass
            elif token in [50]:
                localctx = CompiscriptParser.ThisExprContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 430
                self.match(CompiscriptParser.T__49)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SuffixOpContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return CompiscriptParser.RULE_suffixOp

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class CallExprContext(SuffixOpContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CompiscriptParser.SuffixOpContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def arguments(self):
            return self.getTypedRuleContext(CompiscriptParser.ArgumentsContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCallExpr" ):
                listener.enterCallExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCallExpr" ):
                listener.exitCallExpr(self)


    class PropertyAccessExprContext(SuffixOpContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CompiscriptParser.SuffixOpContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Identifier(self):
            return self.getToken(CompiscriptParser.Identifier, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPropertyAccessExpr" ):
                listener.enterPropertyAccessExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPropertyAccessExpr" ):
                listener.exitPropertyAccessExpr(self)


    class IndexExprContext(SuffixOpContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CompiscriptParser.SuffixOpContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self):
            return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIndexExpr" ):
                listener.enterIndexExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIndexExpr" ):
                listener.exitIndexExpr(self)



    def suffixOp(self):

        localctx = CompiscriptParser.SuffixOpContext(self, self._ctx, self.state)
        self.enterRule(localctx, 82, self.RULE_suffixOp)
        self._la = 0 # Token type
        try:
            self.state = 444
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [11]:
                localctx = CompiscriptParser.CallExprContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 433
                self.match(CompiscriptParser.T__10)
                self.state = 435
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & 1229449712923314176) != 0):
                    self.state = 434
                    self.arguments()


                self.state = 437
                self.match(CompiscriptParser.T__11)
                pass
            elif token in [51]:
                localctx = CompiscriptParser.IndexExprContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 438
                self.match(CompiscriptParser.T__50)
                self.state = 439
                self.expression()
                self.state = 440
                self.match(CompiscriptParser.T__51)
                pass
            elif token in [9]:
                localctx = CompiscriptParser.PropertyAccessExprContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 442
                self.match(CompiscriptParser.T__8)
                self.state = 443
                self.match(CompiscriptParser.Identifier)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ArgumentsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CompiscriptParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,i)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_arguments

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArguments" ):
                listener.enterArguments(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArguments" ):
                listener.exitArguments(self)




    def arguments(self):

        localctx = CompiscriptParser.ArgumentsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 84, self.RULE_arguments)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 446
            self.expression()
            self.state = 451
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==29:
                self.state = 447
                self.match(CompiscriptParser.T__28)
                self.state = 448
                self.expression()
                self.state = 453
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ArrayLiteralContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CompiscriptParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(CompiscriptParser.ExpressionContext,i)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_arrayLiteral

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArrayLiteral" ):
                listener.enterArrayLiteral(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArrayLiteral" ):
                listener.exitArrayLiteral(self)




    def arrayLiteral(self):

        localctx = CompiscriptParser.ArrayLiteralContext(self, self._ctx, self.state)
        self.enterRule(localctx, 86, self.RULE_arrayLiteral)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 454
            self.match(CompiscriptParser.T__50)
            self.state = 463
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 1229449712923314176) != 0):
                self.state = 455
                self.expression()
                self.state = 460
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==29:
                    self.state = 456
                    self.match(CompiscriptParser.T__28)
                    self.state = 457
                    self.expression()
                    self.state = 462
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)



            self.state = 465
            self.match(CompiscriptParser.T__51)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def baseType(self):
            return self.getTypedRuleContext(CompiscriptParser.BaseTypeContext,0)


        def getRuleIndex(self):
            return CompiscriptParser.RULE_type

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterType" ):
                listener.enterType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitType" ):
                listener.exitType(self)




    def type_(self):

        localctx = CompiscriptParser.TypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 88, self.RULE_type)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 467
            self.baseType()
            self.state = 472
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==51:
                self.state = 468
                self.match(CompiscriptParser.T__50)
                self.state = 469
                self.match(CompiscriptParser.T__51)
                self.state = 474
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BaseTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Identifier(self):
            return self.getToken(CompiscriptParser.Identifier, 0)

        def getRuleIndex(self):
            return CompiscriptParser.RULE_baseType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBaseType" ):
                listener.enterBaseType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBaseType" ):
                listener.exitBaseType(self)




    def baseType(self):

        localctx = CompiscriptParser.BaseTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 90, self.RULE_baseType)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 475
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 1215971899390033920) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





